"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"
import { useRouter } from "next/navigation"
import { api } from "@/lib/api"

type User = {
  id: number
  nome: string
  email: string
  papel: string
  secretaria_id: number | null
  secretaria_nome?: string
}

type AuthContextType = {
  user: User | null
  token: string | null
  login: (email: string, password: string) => Promise<void>
  logout: () => void
  isAuthenticated: boolean
  isLoading: boolean
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [token, setToken] = useState<string | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const router = useRouter()

  useEffect(() => {
    // Verificar se o usuário já está autenticado
    const storedToken = localStorage.getItem("token")
    const storedUser = localStorage.getItem("user")

    if (storedToken && storedUser) {
      setToken(storedToken)
      setUser(JSON.parse(storedUser))
      api.defaults.headers.common["Authorization"] = `Bearer ${storedToken}`
    }

    setIsLoading(false)
  }, [])

  const login = async (email: string, password: string) => {
    try {
      const response = await api.post("/auth/login", {
        email,
        senha: password,
      })

      const { token, usuario } = response.data

      // Buscar informações da secretaria do usuário, se disponível
      if (usuario.secretaria_id) {
        try {
          const secretariaRes = await fetch(`http://biometrico.itaguai.rj.gov.br:3001/secre/${usuario.secretaria_id}`)
          if (secretariaRes.ok) {
            const secretariaData = await secretariaRes.json()
            usuario.secretaria_nome = secretariaData.nome
          }
        } catch (error) {
          console.error("Erro ao buscar informações da secretaria:", error)
        }
      }

      // Salvar no estado
      setToken(token)
      setUser(usuario)

      // Salvar no localStorage
      localStorage.setItem("token", token)
      localStorage.setItem("user", JSON.stringify(usuario))

      // Configurar o token para todas as requisições
      api.defaults.headers.common["Authorization"] = `Bearer ${token}`

      return response.data
    } catch (error) {
      console.error("Erro no login:", error)
      throw error
    }
  }

  const logout = () => {
    // Limpar estado
    setToken(null)
    setUser(null)

    // Limpar localStorage
    localStorage.removeItem("token")
    localStorage.removeItem("user")

    // Remover token das requisições
    delete api.defaults.headers.common["Authorization"]

    // Redirecionar para login
    router.push("/login")
  }

  return (
    <AuthContext.Provider
      value={{
        user,
        token,
        login,
        logout,
        isAuthenticated: !!user,
        isLoading,
      }}
    >
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error("useAuth deve ser usado dentro de um AuthProvider")
  }
  return context
}
