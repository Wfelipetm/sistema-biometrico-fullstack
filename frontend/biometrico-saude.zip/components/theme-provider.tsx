"use client"

import type React from "react"

import { createContext, useContext, useEffect, useState } from "react"
import { useMediaQuery } from "@/hooks/use-media-query"

type Theme = "dark" | "light" | "system"

type ThemeProviderProps = {
  children: React.ReactNode
  defaultTheme?: Theme
  enableSystem?: boolean
  storageKey?: string
  attribute?: string
  disableTransitionOnChange?: boolean
}

type ThemeProviderState = {
  theme: Theme
  setTheme: (theme: Theme) => void
}

const initialState: ThemeProviderState = {
  theme: "system",
  setTheme: () => null,
}

const ThemeProviderContext = createContext<ThemeProviderState>(initialState)

export function ThemeProvider({
  children,
  defaultTheme = "system",
  enableSystem = true,
  storageKey = "ui-theme",
  attribute = "data-theme",
  disableTransitionOnChange = false,
  ...props
}: ThemeProviderProps) {
  const [theme, setTheme] = useState<Theme>(defaultTheme)
  const [mounted, setMounted] = useState(false)
  const prefersDark = useMediaQuery("(prefers-color-scheme: dark)")

  useEffect(() => {
    const root = window.document.documentElement
    const localTheme = localStorage.getItem(storageKey) as Theme | null

    if (localTheme) {
      setTheme(localTheme)
    } else if (enableSystem) {
      setTheme("system")
    }

    setMounted(true)
  }, [enableSystem, storageKey])

  useEffect(() => {
    const root = window.document.documentElement

    if (disableTransitionOnChange) {
      root.classList.add("[&_*]:!transition-none")
      window.setTimeout(() => {
        root.classList.remove("[&_*]:!transition-none")
      }, 0)
    }

    if (theme === "system" && enableSystem) {
      const isDark = prefersDark
      root.classList.toggle("dark", isDark)
      root.style.colorScheme = isDark ? "dark" : "light"
    } else {
      const isDark = theme === "dark"
      root.classList.toggle("dark", isDark)
      root.style.colorScheme = isDark ? "dark" : "light"
    }

    if (attribute === "class") {
      root.classList.remove("light", "dark")
      root.classList.add(theme === "system" ? (prefersDark ? "dark" : "light") : theme)
    } else {
      const attrTheme = theme === "system" ? (prefersDark ? "dark" : "light") : theme
      root.setAttribute(attribute, attrTheme)
    }
  }, [theme, enableSystem, prefersDark, attribute, disableTransitionOnChange])

  const value = {
    theme,
    setTheme: (theme: Theme) => {
      localStorage.setItem(storageKey, theme)
      setTheme(theme)
    },
  }

  // Evitar renderização no servidor para prevenir erros de hidratação
  if (!mounted) {
    return <>{children}</>
  }

  return (
    <ThemeProviderContext.Provider {...props} value={value}>
      {children}
    </ThemeProviderContext.Provider>
  )
}

export const useTheme = () => {
  const context = useContext(ThemeProviderContext)

  if (context === undefined) {
    throw new Error("useTheme must be used within a ThemeProvider")
  }

  return context
}
