"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { api } from "@/lib/api"
import { Button } from "@/components/ui/button"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Plus, Search, Edit, Trash2, FileDown } from "lucide-react"
import { format } from "date-fns"
import { ptBR } from "date-fns/locale"
import { useAuth } from "@/contexts/AuthContext"

type Registro = {
  id: string
  funcionario: string
  unidade: string
  data_hora: string
  hora_entrada: string | null
  hora_saida: string | null
}

export default function RegistrosPage() {
  const [registros, setRegistros] = useState<Registro[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState("")
  const router = useRouter()
  const { user } = useAuth()

  useEffect(() => {
    const fetchRegistros = async () => {
      try {
        if (!user?.secretaria_id) {
          console.error("ID da secretaria não encontrado")
          setLoading(false)
          return
        }

        // Buscar unidades da secretaria do usuário
        const unidadesResponse = await fetch(
          `http://biometrico.itaguai.rj.gov.br:3001/secre/${user.secretaria_id}/unidades`,
        )
        if (!unidadesResponse.ok) {
          throw new Error("Falha ao buscar unidades")
        }
        const unidades = await unidadesResponse.json()

        // Buscar registros para cada unidade
        const registrosPromises = unidades.map((unidade: { id: string }) => api.get(`/unid/${unidade.id}/registros`))

        const registrosResponses = await Promise.all(registrosPromises)
        const todosRegistros = registrosResponses.flatMap((response) => response.data)

        setRegistros(todosRegistros)
      } catch (error) {
        console.error("Erro ao buscar registros:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchRegistros()
  }, [user])

  const handleDelete = async (id: string) => {
    if (window.confirm("Tem certeza que deseja excluir este registro?")) {
      try {
        await api.delete(`/reg/registros-ponto/${id}`)
        setRegistros(registros.filter((registro) => registro.id !== id))
      } catch (error) {
        console.error("Erro ao excluir registro:", error)
      }
    }
  }

  const filteredRegistros = registros.filter(
    (registro) =>
      registro.funcionario.toLowerCase().includes(searchTerm.toLowerCase()) ||
      registro.unidade.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  const formatDate = (dateString: string) => {
    try {
      return format(new Date(dateString), "dd/MM/yyyy", { locale: ptBR })
    } catch (error) {
      return dateString
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Registros de Ponto</h1>
          <p className="text-muted-foreground">
            Gerencie os registros de ponto da {user?.secretaria_nome || "secretaria"}
          </p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={() => {}}>
            <FileDown className="mr-2 h-4 w-4" /> Exportar
          </Button>
          <Button onClick={() => router.push("/dashboard/registros/novo")}>
            <Plus className="mr-2 h-4 w-4" /> Novo Registro
          </Button>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Lista de Registros</CardTitle>
          <CardDescription>Total de {registros.length} registros de ponto</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="mb-4 flex items-center gap-2">
            <Search className="h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Buscar registro..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="max-w-sm"
            />
          </div>

          {loading ? (
            <div className="flex items-center justify-center py-8">
              <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-primary"></div>
            </div>
          ) : (
            <div className="rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Funcionário</TableHead>
                    <TableHead>Unidade</TableHead>
                    <TableHead>Data</TableHead>
                    <TableHead>Entrada</TableHead>
                    <TableHead>Saída</TableHead>
                    <TableHead className="text-right">Ações</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredRegistros.length > 0 ? (
                    filteredRegistros.map((registro) => (
                      <TableRow key={registro.id}>
                        <TableCell className="font-medium">{registro.funcionario}</TableCell>
                        <TableCell>{registro.unidade}</TableCell>
                        <TableCell>{formatDate(registro.data_hora)}</TableCell>
                        <TableCell>{registro.hora_entrada || "-"}</TableCell>
                        <TableCell>{registro.hora_saida || "-"}</TableCell>
                        <TableCell className="text-right">
                          <div className="flex justify-end gap-2">
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => router.push(`/dashboard/registros/editar/${registro.id}`)}
                            >
                              <Edit className="h-4 w-4" />
                              <span className="sr-only">Editar</span>
                            </Button>
                            <Button variant="ghost" size="icon" onClick={() => handleDelete(registro.id)}>
                              <Trash2 className="h-4 w-4" />
                              <span className="sr-only">Excluir</span>
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))
                  ) : (
                    <TableRow>
                      <TableCell colSpan={6} className="h-24 text-center">
                        Nenhum registro encontrado.
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
