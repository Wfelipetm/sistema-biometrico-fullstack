"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Building2, Users, Clock, CalendarClock } from "lucide-react"
import { useAuth } from "@/contexts/AuthContext"

type Unidade = {
  id: string
  nome: string
}

type Funcionario = {
  id: string
  nome: string
}

type Registro = {
  id: string
  data_hora: string
}

type SecretariaStats = {
  unidades: Unidade[]
  funcionarios: Funcionario[]
  registrosHoje: Registro[]
  registrosMes: Registro[]
}

export default function DashboardPage() {
  const { user } = useAuth()
  const [stats, setStats] = useState<SecretariaStats>({
    unidades: [],
    funcionarios: [],
    registrosHoje: [],
    registrosMes: [],
  })
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchSecretariaData = async () => {
      try {
        if (!user?.secretaria_id) {
          console.error("ID da secretaria não encontrado")
          setLoading(false)
          return
        }

        // Buscar unidades da secretaria do usuário
        const unidadesResponse = await fetch(
          `http://biometrico.itaguai.rj.gov.br:3001/secre/${user.secretaria_id}/unidades`,
        )
        if (!unidadesResponse.ok) {
          throw new Error("Falha ao buscar unidades")
        }
        const unidades = await unidadesResponse.json()

        // Buscar funcionários para cada unidade
        const funcionariosPromises = unidades.map((unidade: { id: string }) =>
          fetch(`http://biometrico.itaguai.rj.gov.br:3001/unid/${unidade.id}/funcionarios`),
        )

        const funcionariosResponses = await Promise.all(funcionariosPromises)
        const funcionariosData = await Promise.all(funcionariosResponses.map((response) => response.json()))
        const todosFuncionarios = funcionariosData.flat()

        // Obter data de hoje e primeiro dia do mês para filtrar registros
        const hoje = new Date()
        const dataHoje = hoje.toISOString().split("T")[0]
        const primeiroDiaMes = new Date(hoje.getFullYear(), hoje.getMonth(), 1).toISOString().split("T")[0]

        // Buscar registros de hoje para cada unidade
        const registrosHojePromises = unidades.map((unidade: { id: string }) =>
          fetch(`http://biometrico.itaguai.rj.gov.br:3001/unid/${unidade.id}/registros?data=${dataHoje}`),
        )

        // Buscar registros do mês para cada unidade
        const registrosMesPromises = unidades.map((unidade: { id: string }) =>
          fetch(
            `http://biometrico.itaguai.rj.gov.br:3001/unid/${unidade.id}/registros?data_inicio=${primeiroDiaMes}&data_fim=${dataHoje}`,
          ),
        )

        const registrosHojeResponses = await Promise.all(registrosHojePromises)
        const registrosMesResponses = await Promise.all(registrosMesPromises)

        const registrosHojeData = await Promise.all(registrosHojeResponses.map((response) => response.json()))
        const registrosMesData = await Promise.all(registrosMesResponses.map((response) => response.json()))

        const todosRegistrosHoje = registrosHojeData.flat()
        const todosRegistrosMes = registrosMesData.flat()

        setStats({
          unidades,
          funcionarios: todosFuncionarios,
          registrosHoje: todosRegistrosHoje,
          registrosMes: todosRegistrosMes,
        })
      } catch (error) {
        console.error("Erro ao carregar dados da secretaria:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchSecretariaData()
  }, [user])

  if (loading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Secretaria</h1>
        <p className="text-muted-foreground">
          Bem-vindo, {user?.nome}! Aqui está um resumo da {user?.secretaria_nome || "sua secretaria"}.
        </p>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Unidades</CardTitle>
            <Building2 className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.unidades.length}</div>
            <p className="text-xs text-muted-foreground">Total de unidades na secretaria</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Funcionários</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.funcionarios.length}</div>
            <p className="text-xs text-muted-foreground">Total de funcionários na secretaria</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Registros Hoje</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.registrosHoje.length}</div>
            <p className="text-xs text-muted-foreground">Registros de ponto realizados hoje</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Registros no Mês</CardTitle>
            <CalendarClock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.registrosMes.length}</div>
            <p className="text-xs text-muted-foreground">Total de registros no mês atual</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        <Card className="col-span-1">
          <CardHeader>
            <CardTitle>Unidades da Secretaria</CardTitle>
            <CardDescription>Unidades vinculadas à sua secretaria</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {stats.unidades.length > 0 ? (
                <ul className="space-y-2">
                  {stats.unidades.slice(0, 5).map((unidade) => (
                    <li key={unidade.id} className="flex items-center justify-between border-b pb-2">
                      <span className="font-medium">{unidade.nome}</span>
                    </li>
                  ))}
                  {stats.unidades.length > 5 && (
                    <li className="text-sm text-muted-foreground text-center pt-2">
                      + {stats.unidades.length - 5} outras unidades
                    </li>
                  )}
                </ul>
              ) : (
                <p className="text-sm text-muted-foreground">Nenhuma unidade encontrada</p>
              )}
            </div>
          </CardContent>
        </Card>

        <Card className="col-span-1">
          <CardHeader>
            <CardTitle>Funcionários Recentes</CardTitle>
            <CardDescription>Últimos funcionários cadastrados</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {stats.funcionarios.length > 0 ? (
                <ul className="space-y-2">
                  {stats.funcionarios.slice(0, 5).map((funcionario) => (
                    <li key={funcionario.id} className="flex items-center justify-between border-b pb-2">
                      <span className="font-medium">{funcionario.nome}</span>
                    </li>
                  ))}
                  {stats.funcionarios.length > 5 && (
                    <li className="text-sm text-muted-foreground text-center pt-2">
                      + {stats.funcionarios.length - 5} outros funcionários
                    </li>
                  )}
                </ul>
              ) : (
                <p className="text-sm text-muted-foreground">Nenhum funcionário encontrado</p>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
