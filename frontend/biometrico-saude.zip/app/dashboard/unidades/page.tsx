"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { api } from "@/lib/api"
import { Button } from "@/components/ui/button"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Plus, Search, Edit, Trash2 } from "lucide-react"
import { useAuth } from "@/contexts/AuthContext"

type Unidade = {
  id: string
  nome: string
  localizacao: string
  created_at: string
  updated_at: string
}

export default function UnidadesPage() {
  const [unidades, setUnidades] = useState<Unidade[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState("")
  const router = useRouter()
  const { user } = useAuth()

  useEffect(() => {
    const fetchUnidades = async () => {
      try {
        if (!user?.secretaria_id) {
          console.error("ID da secretaria não encontrado")
          setLoading(false)
          return
        }

        // Buscar unidades da secretaria do usuário
        const response = await fetch(`http://biometrico.itaguai.rj.gov.br:3001/secre/${user.secretaria_id}/unidades`)
        if (!response.ok) {
          throw new Error("Falha ao buscar unidades")
        }
        const data = await response.json()
        setUnidades(data)
      } catch (error) {
        console.error("Erro ao buscar unidades:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchUnidades()
  }, [user])

  const handleDelete = async (id: string) => {
    if (window.confirm("Tem certeza que deseja excluir esta unidade?")) {
      try {
        await api.delete(`/unid/unidade/${id}`)
        setUnidades(unidades.filter((unidade) => unidade.id !== id))
      } catch (error) {
        console.error("Erro ao excluir unidade:", error)
      }
    }
  }

  const filteredUnidades = unidades.filter(
    (unidade) =>
      unidade.nome.toLowerCase().includes(searchTerm.toLowerCase()) ||
      unidade.localizacao.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Unidades</h1>
          <p className="text-muted-foreground">Gerencie as unidades da {user?.secretaria_nome || "secretaria"}</p>
        </div>
        <Button onClick={() => router.push("/dashboard/unidades/nova")}>
          <Plus className="mr-2 h-4 w-4" /> Nova Unidade
        </Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Lista de Unidades</CardTitle>
          <CardDescription>Total de {unidades.length} unidades cadastradas</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="mb-4 flex items-center gap-2">
            <Search className="h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Buscar unidade..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="max-w-sm"
            />
          </div>

          {loading ? (
            <div className="flex items-center justify-center py-8">
              <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-primary"></div>
            </div>
          ) : (
            <div className="rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Nome</TableHead>
                    <TableHead>Localização</TableHead>
                    <TableHead className="text-right">Ações</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredUnidades.length > 0 ? (
                    filteredUnidades.map((unidade) => (
                      <TableRow key={unidade.id}>
                        <TableCell className="font-medium">{unidade.nome}</TableCell>
                        <TableCell>{unidade.localizacao}</TableCell>
                        <TableCell className="text-right">
                          <div className="flex justify-end gap-2">
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => router.push(`/dashboard/unidades/editar/${unidade.id}`)}
                            >
                              <Edit className="h-4 w-4" />
                              <span className="sr-only">Editar</span>
                            </Button>
                            <Button variant="ghost" size="icon" onClick={() => handleDelete(unidade.id)}>
                              <Trash2 className="h-4 w-4" />
                              <span className="sr-only">Excluir</span>
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))
                  ) : (
                    <TableRow>
                      <TableCell colSpan={3} className="h-24 text-center">
                        Nenhuma unidade encontrada.
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
