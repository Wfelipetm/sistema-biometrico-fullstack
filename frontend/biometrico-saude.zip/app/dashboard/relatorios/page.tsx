"use client"

import { useState, useEffect } from "react"
import { api } from "@/lib/api"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { FileDown } from "lucide-react"

type Funcionario = {
  id: string
  nome: string
}

type RelatorioItem = {
  data: string
  hora_entrada: string
  hora_saida: string
  funcionario_nome: string
  unidade_nome: string
}

export default function RelatoriosPage() {
  const [funcionarios, setFuncionarios] = useState<Funcionario[]>([])
  const [funcionarioId, setFuncionarioId] = useState("")
  const [mes, setMes] = useState(new Date().getMonth() + 1 + "")
  const [ano, setAno] = useState(new Date().getFullYear() + "")
  const [relatorio, setRelatorio] = useState<RelatorioItem[]>([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState("")

  useEffect(() => {
    const fetchFuncionarios = async () => {
      try {
        const response = await api.get("/funci/funcionarios")
        setFuncionarios(response.data)
      } catch (error) {
        console.error("Erro ao buscar funcionários:", error)
        setError("Não foi possível carregar os funcionários.")
      }
    }

    fetchFuncionarios()
  }, [])

  const handleGerarRelatorio = async () => {
    if (!funcionarioId) {
      setError("Selecione um funcionário")
      return
    }

    setLoading(true)
    setError("")

    try {
      const response = await api.get(`/reg/pontos`, {
        params: {
          funcionario_id: funcionarioId,
          mes,
          ano,
        },
      })
      setRelatorio(response.data)
    } catch (error) {
      console.error("Erro ao gerar relatório:", error)
      setError("Erro ao gerar relatório. Tente novamente.")
    } finally {
      setLoading(false)
    }
  }

  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return date.toLocaleDateString("pt-BR")
  }

  const meses = [
    { value: "1", label: "Janeiro" },
    { value: "2", label: "Fevereiro" },
    { value: "3", label: "Março" },
    { value: "4", label: "Abril" },
    { value: "5", label: "Maio" },
    { value: "6", label: "Junho" },
    { value: "7", label: "Julho" },
    { value: "8", label: "Agosto" },
    { value: "9", label: "Setembro" },
    { value: "10", label: "Outubro" },
    { value: "11", label: "Novembro" },
    { value: "12", label: "Dezembro" },
  ]

  const anos = Array.from({ length: 5 }, (_, i) => {
    const year = new Date().getFullYear() - 2 + i
    return { value: year.toString(), label: year.toString() }
  })

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Relatórios</h1>
        <p className="text-muted-foreground">Gere relatórios de ponto dos funcionários</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Relatório de Ponto</CardTitle>
          <CardDescription>Selecione um funcionário e o período para gerar o relatório</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-4">
            <div className="grid gap-2">
              <Label htmlFor="funcionario">Funcionário</Label>
              <Select value={funcionarioId} onValueChange={setFuncionarioId}>
                <SelectTrigger>
                  <SelectValue placeholder="Selecione um funcionário" />
                </SelectTrigger>
                <SelectContent>
                  {funcionarios.map((funcionario) => (
                    <SelectItem key={funcionario.id} value={funcionario.id}>
                      {funcionario.nome}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="grid gap-2">
              <Label htmlFor="mes">Mês</Label>
              <Select value={mes} onValueChange={setMes}>
                <SelectTrigger>
                  <SelectValue placeholder="Selecione o mês" />
                </SelectTrigger>
                <SelectContent>
                  {meses.map((mes) => (
                    <SelectItem key={mes.value} value={mes.value}>
                      {mes.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="grid gap-2">
              <Label htmlFor="ano">Ano</Label>
              <Select value={ano} onValueChange={setAno}>
                <SelectTrigger>
                  <SelectValue placeholder="Selecione o ano" />
                </SelectTrigger>
                <SelectContent>
                  {anos.map((ano) => (
                    <SelectItem key={ano.value} value={ano.value}>
                      {ano.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="flex items-end">
              <Button onClick={handleGerarRelatorio} disabled={loading}>
                {loading ? "Gerando..." : "Gerar Relatório"}
              </Button>
            </div>
          </div>

          {error && <p className="mt-4 text-sm text-destructive">{error}</p>}

          {relatorio.length > 0 && (
            <div className="mt-6">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg font-semibold">Resultados</h3>
                <Button variant="outline" size="sm">
                  <FileDown className="mr-2 h-4 w-4" /> Exportar
                </Button>
              </div>
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Data</TableHead>
                      <TableHead>Entrada</TableHead>
                      <TableHead>Saída</TableHead>
                      <TableHead>Funcionário</TableHead>
                      <TableHead>Unidade</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {relatorio.map((item, index) => (
                      <TableRow key={index}>
                        <TableCell>{formatDate(item.data)}</TableCell>
                        <TableCell>{item.hora_entrada}</TableCell>
                        <TableCell>{item.hora_saida}</TableCell>
                        <TableCell>{item.funcionario_nome}</TableCell>
                        <TableCell>{item.unidade_nome}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
