"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { api } from "@/lib/api"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { AlertCircle, ArrowLeft } from "lucide-react"
import { Alert, AlertDescription } from "@/components/ui/alert"

type Unidade = {
  id: string
  nome: string
}

export default function NovoFuncionarioPage() {
  const [nome, setNome] = useState("")
  const [cpf, setCpf] = useState("")
  const [cargo, setCargo] = useState("")
  const [unidadeId, setUnidadeId] = useState("")
  const [dataAdmissao, setDataAdmissao] = useState("")
  const [idBiometrico, setIdBiometrico] = useState("")
  const [unidades, setUnidades] = useState<Unidade[]>([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState("")
  const router = useRouter()

  useEffect(() => {
    const fetchUnidades = async () => {
      try {
        const response = await api.get("/unid/unidades")
        setUnidades(response.data)
      } catch (error) {
        console.error("Erro ao buscar unidades:", error)
        setError("Não foi possível carregar as unidades.")
      }
    }

    fetchUnidades()
  }, [])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError("")
    setLoading(true)

    try {
      await api.post("/funci/funcionario", {
        nome,
        cpf,
        cargo,
        unidade_id: unidadeId,
        data_admissao: dataAdmissao,
        id_biometrico: idBiometrico,
      })

      router.push("/dashboard/funcionarios")
    } catch (err) {
      console.error("Erro ao cadastrar funcionário:", err)
      setError("Erro ao cadastrar funcionário. Verifique os dados e tente novamente.")
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-2">
        <Button variant="ghost" size="icon" onClick={() => router.back()}>
          <ArrowLeft className="h-4 w-4" />
        </Button>
        <h1 className="text-3xl font-bold tracking-tight">Novo Funcionário</h1>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Cadastro de Funcionário</CardTitle>
          <CardDescription>Preencha os dados para cadastrar um novo funcionário</CardDescription>
        </CardHeader>
        <form onSubmit={handleSubmit}>
          <CardContent className="space-y-4">
            {error && (
              <Alert variant="destructive">
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}

            <div className="grid gap-2">
              <Label htmlFor="nome">Nome Completo</Label>
              <Input id="nome" value={nome} onChange={(e) => setNome(e.target.value)} required />
            </div>

            <div className="grid gap-2">
              <Label htmlFor="cpf">CPF</Label>
              <Input id="cpf" value={cpf} onChange={(e) => setCpf(e.target.value)} required />
            </div>

            <div className="grid gap-2">
              <Label htmlFor="cargo">Cargo</Label>
              <Input id="cargo" value={cargo} onChange={(e) => setCargo(e.target.value)} required />
            </div>

            <div className="grid gap-2">
              <Label htmlFor="unidade">Unidade</Label>
              <Select value={unidadeId} onValueChange={setUnidadeId} required>
                <SelectTrigger>
                  <SelectValue placeholder="Selecione uma unidade" />
                </SelectTrigger>
                <SelectContent>
                  {unidades.map((unidade) => (
                    <SelectItem key={unidade.id} value={unidade.id}>
                      {unidade.nome}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="grid gap-2">
              <Label htmlFor="dataAdmissao">Data de Admissão</Label>
              <Input
                id="dataAdmissao"
                type="date"
                value={dataAdmissao}
                onChange={(e) => setDataAdmissao(e.target.value)}
                required
              />
            </div>

            <div className="grid gap-2">
              <Label htmlFor="idBiometrico">ID Biométrico</Label>
              <Input
                id="idBiometrico"
                value={idBiometrico}
                onChange={(e) => setIdBiometrico(e.target.value)}
                required
              />
            </div>
          </CardContent>
          <CardFooter className="flex justify-between">
            <Button variant="outline" type="button" onClick={() => router.back()}>
              Cancelar
            </Button>
            <Button type="submit" disabled={loading}>
              {loading ? "Salvando..." : "Salvar"}
            </Button>
          </CardFooter>
        </form>
      </Card>
    </div>
  )
}
